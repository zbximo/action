# Copyright (c) Hikvision Research Institute. All rights reserved.
from .hungarian_assigner import PoseHungarianAssigner

__all__ = ['PoseHungarianAssigner']
