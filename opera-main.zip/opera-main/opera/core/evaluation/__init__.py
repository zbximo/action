# Copyright (c) Hikvision Research Institute. All rights reserved.
from .eval_hooks import DistEvalHook, EvalHook

__all__ = ['DistEvalHook', 'EvalHook']
